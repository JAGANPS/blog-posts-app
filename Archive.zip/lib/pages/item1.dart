import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class Item1 extends StatefulWidget {
  Item1({Key key}) : super(key: key);

  @override
  _Item1State createState() => _Item1State();
}

class _Item1State extends State<Item1> {


Future getPost()async{
  var firestore = Firestore.instance;
  QuerySnapshot snap= await firestore.collection("item1").getDocuments();
  return snap.documents;
}

Future<Null>getRefres()async{
  await Future.delayed(Duration(seconds: 3));
  setState(() {
    getPost();

  });
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: getPost(),
        builder: (context,snapshot){
          if(snapshot.connectionState == ConnectionState.waiting){
            return Center(
              child: CircularProgressIndicator(),
            );
          }else{
            return RefreshIndicator(
              onRefresh: getRefres,
              child: ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (context,index){
                  var ourData = snapshot.data[index];
                  return Container(
                    height: 200,
                    margin: EdgeInsets.all(5.0),
                    child: Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0)
                      ),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 2,
                            child: ClipRRect(
                             borderRadius: BorderRadius.circular(20.0),
                              child: Image.network(ourData.data['image'],
                              height:170,
                              fit: BoxFit.cover,

                              ) ,
                              
                            ),

                          ),
                          SizedBox(
                            width: 5.0,
                          ),
                          Expanded(
                            flex: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                  child: Text(ourData.data['des'],
                                  maxLines: 5,
                                  style:TextStyle(fontSize:20.0, 
                                  color: Colors.black),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.bottomRight,
                                  child: InkWell(
                                    onTap: (){
                                      customDialog(context, ourData.data['image'],ourData.data['title'] , ourData.data['des']);
                                    },
                                    child: Container(
                                    height: 40.0,
                                    margin: EdgeInsets.all(10.0),
                                    padding: EdgeInsets.all(10.0),
                                   decoration: BoxDecoration(
                                     
                                     color: Colors.cyan,
                                     borderRadius: BorderRadius.circular(30.0)
                                   ),
                                  child: Text("view Details",
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    color: Colors.white
                                  ),),
                                  ),
                                  ),
                                ),
                              ],
                            ),
                          )

                        ],
                      )
                    ),
                  );
                },
              ),
            );
          }
        },
      ),
    );
  }
  customDialog(BuildContext context,String image,String title,String des){
    return showDialog(
          context: context,
          builder: (BuildContext context){
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0),),
                child:Container(
                  height: MediaQuery.of(context).size.height/1,
                  width: MediaQuery.of(context).size.width,

                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20.0),
                    gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end:Alignment.bottomLeft,
                      colors: [
                        Colors.deepPurple,
                        Colors.deepOrange,
                        Colors.green,

                      ]
                    )
                  ),
                  child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          height: 200.0,
                     
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: Image.network(image,
                            
                            height: 150.0,
                            width: MediaQuery.of(context).size.width,
                            fit:BoxFit.cover,
                            ),
                          ),
                        ),
                        SizedBox(height: 6.0,),
                        Container(
                          padding: EdgeInsets.all(10.0),
                          child: Text(des,
                          style:TextStyle(fontSize:20.0,
                          color: Colors.white),
                          ),
                        )
                      ],
                    ),
                  ),
                )
              
            );
          }
    );
  }
}