import 'package:flutter/material.dart';
import 'home.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
   home:Home(),
  ));
}