import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:postbox/pages/item1.dart';
import 'package:postbox/pages/item2.dart';
import 'package:postbox/pages/item3.dart';
class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
 int _indexpage =1;
 final pageoption=[
Item1(),
Item2(),
Item3(),
 ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
         title: Text("BlogPosts"),
         backgroundColor: Colors.cyan,
       ),
       body: pageoption[_indexpage],


       bottomNavigationBar: CurvedNavigationBar(
         color: Colors.cyan,
         
          buttonBackgroundColor: Colors.transparent,
          backgroundColor: Colors.lightBlue,
          animationCurve: Curves.easeInOutBack,
          animationDuration: Duration(milliseconds: 300),
           index: 1,
         items:<Widget>[
      Icon(Icons.poll, size: 25,),
      Icon(Icons.home, size: 25),
      Icon(Icons.library_books, size: 25),
    ],
       onTap: (int index){
         setState(() {
           _indexpage=index;
         });
         
       },
       ),
    





    );
  }
}